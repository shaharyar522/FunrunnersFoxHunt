 <!-- Regions Section -->
    <section id="regions" class="regions">
{{-- now image only --}}
    </section>
