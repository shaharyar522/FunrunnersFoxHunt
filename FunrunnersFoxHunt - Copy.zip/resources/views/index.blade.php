@extends('layouts.app')


@section('title', 'Looking for the Foxiest Woman on Earth')



@section('content')


@include('partials.navbar')
@include('partials.hero')
@include('partials.how-it-works')
@include('partials.regions')
@include('partials.rules')
@include('partials.login-icon')
@include('partials.footer')

@endsection

