 <!-- Regions Section -->
    <section id="regions" class="regions">

    </section>
<?php /**PATH D:\FunrunnersFoxHunt\resources\views/partials/regions.blade.php ENDPATH**/ ?>